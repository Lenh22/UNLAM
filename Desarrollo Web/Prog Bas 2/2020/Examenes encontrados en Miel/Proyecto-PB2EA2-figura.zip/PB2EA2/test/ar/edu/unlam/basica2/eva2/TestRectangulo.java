package ar.edu.unlam.basica2.eva2;

public class TestRectangulo {

	//Desarrolle Todos Los test para verificar el correcto funcionamiento de Un Rectangulo
}
