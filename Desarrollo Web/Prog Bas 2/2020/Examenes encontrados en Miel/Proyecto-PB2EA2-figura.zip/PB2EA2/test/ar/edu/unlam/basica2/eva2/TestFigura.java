package ar.edu.unlam.basica2.eva2;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestFigura {
	
	
	@Test
	public void testQueVerificaQueUnaMismaFiguraSePuedaInstanciaTantoComoUnRectangoYTambienComoUncirculo() {
		
	}

}
