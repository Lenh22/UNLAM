package ar.edu.unlam.basica2.eva2;

import static org.junit.Assert.*;

import org.junit.Test;

public class TestContenedor {

	@Test
	public void testQueSeAgregueUnTriangulo() {
		
	}
	@Test
	public void testQueSeAgregueUnCirculo() {
		
	}
	@Test
	public void testQueSeAgregueUnaFigura() {
		
	}
	@Test
	public void testQueVerificaQueSeObtieneRectangulos() {
		
	}
	
	@Test
	public void testQueElPromedioDetodasLasFiguras() {
		
	}
	
	@Test
	public void testQueVerificaQueUnaMismaFiguraSePuedaInstanciaTantoComoUnRectangoYTambienComoUncirculo() {
		
	}
	

}
