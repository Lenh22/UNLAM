package ar.edu.unlam.basica2.eva2;

public class Rectangulo extends Figura {
	

	
	public Rectangulo(Double ladoA, Double ladoB,String Color){

	}

	
	


}
