package ar.edu.unlam.basica2.eva2;

import java.lang.Math;

public class Circulo extends Figura {

	
	public Circulo(double radio,String Color){
		
	}

	
}
