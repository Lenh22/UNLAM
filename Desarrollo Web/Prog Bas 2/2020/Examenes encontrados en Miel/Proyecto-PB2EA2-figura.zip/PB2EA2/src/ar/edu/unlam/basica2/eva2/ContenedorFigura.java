package ar.edu.unlam.basica2.eva2;

public class ContenedorFigura {

	
	
	public Boolean agregar (Figura figura) {
		
	}
	
	public ArrayList <Rectangulo> obtenerRectangulos (){
		
	}
	
	public LinkedList <Circulo> obtenerCirculos() {
		
	}
	
	public Double calcularPromedioDeAreaDeTodasLasFiguras() {
		
	}
	
	
}
