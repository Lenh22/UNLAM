package ar.edu.unlam.pb2.ea1;

public class PlatoTest {

	public void testQueSePuedanAgregarIngredientesIguales(){
		
	}
	public void testQueSeObtengaLaCantidadDeSalCorrecta(){
		
	}
	
	public void testQueSeObtenegaLaCanidadDeAzucarCorrecta() {
		
	}
	
}
