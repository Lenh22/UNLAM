package ar.edu.unlam.pb2.ea1;

public class PacienteTest {
	public void testQueUnDiabeticoIngesteDietaAptaParaDiabetico() {

	}
	public void testQueUnDiabeticoNoIngesteDietaAptaParaDiabetico() {

	}

	public void testQueUnHipertendoIngesteDietaAptaParaHipertenso() {

	}
	public void testQueUnHipertendoNoIngesteDietaAptaParaHipertenso() {

	}
}
