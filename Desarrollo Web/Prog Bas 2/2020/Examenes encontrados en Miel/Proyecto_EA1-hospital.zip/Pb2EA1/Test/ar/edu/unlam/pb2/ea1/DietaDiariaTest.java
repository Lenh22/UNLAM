package ar.edu.unlam.pb2.ea1;

public class DietaDiariaTest {
	public void testQueNosePuedanAgregarPlatoRepetidos() {

	}
	
	public void testQueDietaDiariaSeaAptaHipertenso(){
		
	}
	
	public void testQueDietaDiariaNoSeaAptaHipertenso(){
		
	}
	public void testQueDietaDiariaSeaAptaDiabetico(){
		
	}
	public void testQueDietaDiariaNoSeaAptaDiabetico(){
		
	}
}
