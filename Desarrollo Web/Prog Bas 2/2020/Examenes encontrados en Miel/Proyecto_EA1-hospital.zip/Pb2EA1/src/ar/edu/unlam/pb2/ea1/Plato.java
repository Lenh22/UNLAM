package ar.edu.unlam.pb2.ea1;


import java.util.ArrayList;

public class Plato {

	/** Por ejemplo, si para un Plato se necesitan DOS (2) tomates,
	se deber� agregar DOS(2) unidades de tomate. 
	*/
	private ArrayList<Ingrediente> ingredientes = new ArrayList<Ingrediente>();
	
	public Integer obtenerCantidadaDeSal(){
		return null;		
	}
	
	public Integer obtenerCantidadDeAzucar(){
		return null;		
	}
}
