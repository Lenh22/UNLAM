package ar.edu.unlam.pb2.ea1;

import java.util.HashSet;

public class DietaDiaria {

	/**
	 * No se permite repetir platos duarante todo el d�a.
	 */
	private HashSet<Plato> platos;
	
	private Integer totalDeSalEnDieta(){
		return null;		
	}
	
	private Integer totalDeAzucarEnDieta(){
		return null;		
	}
	
	public Boolean aptaHipertenso(){
		return null;
		
	}
	public Boolean aptaDiabetico(){
		return null;
		
	}
}
