package ar.edu.unlam.pb2.ea1;

import java.util.ArrayList;

public class Diabetico extends Paciente {
	private Integer azucarEnSangre;

	@Override
	public void agregarDietaDiaria(DietaDiaria dieta) {
		// Control de dieta para un Diab�tico

	}
}
