package ar.edu.unlam.pb2.ea1;

public class Ingrediente {

	private String nombre;
	private Integer cantidadSal;
	private Integer cantidadAzucar;

	public Ingrediente(String nombre, Integer cantidadSal,
			Integer cantidadAzucar) {
		this.nombre = nombre;
		this.cantidadSal = cantidadSal;
		this.cantidadAzucar = cantidadAzucar;
	}

}
