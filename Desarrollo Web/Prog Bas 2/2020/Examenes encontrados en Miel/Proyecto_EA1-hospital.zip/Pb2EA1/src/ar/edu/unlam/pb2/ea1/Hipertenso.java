package ar.edu.unlam.pb2.ea1;

public class Hipertenso extends Paciente{
	private Integer prensionMinima;
	private Integer presionMaxima;
	@Override
	public void agregarDietaDiaria(DietaDiaria dieta) {
		// Control de dieta para un Hipertenso
	}
	
}
