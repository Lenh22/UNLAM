package ar.edu.unlam.pb220202c.eva03;

public class VehiculoNotFounException extends Exception {
	public VehiculoNotFounException() {}
	public VehiculoNotFounException(String mensaje) {
		super(mensaje);
	}

}
