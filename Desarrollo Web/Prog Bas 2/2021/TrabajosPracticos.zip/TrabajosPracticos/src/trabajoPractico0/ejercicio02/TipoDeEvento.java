package trabajoPractico0.ejercicio02;

public enum TipoDeEvento {
GOL_A_FAVOR,
GOL_EN_CONTRA,
AMONESTACION,
EXPULSION
}
