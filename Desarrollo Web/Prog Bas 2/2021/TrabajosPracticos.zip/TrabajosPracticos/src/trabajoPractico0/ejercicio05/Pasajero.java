package trabajoPractico0.ejercicio05;

public class Pasajero {

}
