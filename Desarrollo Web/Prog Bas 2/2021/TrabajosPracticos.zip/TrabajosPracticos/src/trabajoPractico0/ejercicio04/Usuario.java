package trabajoPractico0.ejercicio04;

public class Usuario {
	
	public boolean agregarNuevaLista(String nombreDeLaLista) {
		// Agrega una nueva lista de reproducci�n		
		return false;
	}
	
	public String verMisListasDeReproduccion() {
		// Devuelve el listado de listas de reproducci�n disponible en forma de String (debe brindar informaci�n adecuada de cada lista, por ejemplo su duraci�n)
		return "";
	}
	
	public String reproducirMiLista(int numeroDeLaLista) {
		// Devuelve una lista de reproducci�n determinada en forma de String, incluyendo cada una de sus canciones y la informaci�n de cada canci�n (por ejemplo autor y duraci�n)
		return "";
	}
	
}
