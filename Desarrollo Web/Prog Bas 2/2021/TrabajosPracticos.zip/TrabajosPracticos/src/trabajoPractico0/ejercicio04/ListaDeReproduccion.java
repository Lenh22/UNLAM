package trabajoPractico0.ejercicio04;

public class ListaDeReproduccion {


	public boolean agregarCancion(Cancion nueva) {
		// Se debe agregar una nueva canci�n a la lista de reproducci�n
		return false;
	}
	
	private Cancion buscarCancion(String nombre) {
		// Busca una canci�n en la lista de reproducci�n a partir de su nombre
		return null;
	}
	
	public boolean eliminarCancion(String nombre) {
		// Elimna una canci�n de la lista de reproducci�n
		return false;
	}
	
	public String toString() {
		// Devuelve la lista de canciones de la lista de reproducci�n, junto con la informaci�n necesaria para conocer el detalle de cada canci�n
		return "";
	}
}
