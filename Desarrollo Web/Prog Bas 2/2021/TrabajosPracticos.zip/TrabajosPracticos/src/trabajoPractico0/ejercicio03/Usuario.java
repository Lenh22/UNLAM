package trabajoPractico0.ejercicio03;

public class Usuario {

}
