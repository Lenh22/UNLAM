package trabajoPractico0.ejercicio03;

public class Sistema {
	private String nombreDelSistema;
	private Usuario usuarios[];

}
