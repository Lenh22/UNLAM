package ar.edu.unlam.pb2;

public class ProductoInexistente extends Exception {
	
	public ProductoInexistente(String string) {
		super(string);
	}
}
