package ar.edu.unlam.pb2;

public class ProductoSinStock extends NullPointerException {
	
	public ProductoSinStock(String string) {
		super(string);
	}

}
