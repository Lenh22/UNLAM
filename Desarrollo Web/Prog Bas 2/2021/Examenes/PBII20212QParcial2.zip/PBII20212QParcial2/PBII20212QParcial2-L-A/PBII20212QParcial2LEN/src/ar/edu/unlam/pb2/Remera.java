package ar.edu.unlam.pb2;

public class Remera extends Indumentaria {

	public Remera(Integer clave, String descripcion, String talle, String marca, String color, Double precio) {
		super(clave, descripcion, talle, marca, color, precio);
		
	}

}
