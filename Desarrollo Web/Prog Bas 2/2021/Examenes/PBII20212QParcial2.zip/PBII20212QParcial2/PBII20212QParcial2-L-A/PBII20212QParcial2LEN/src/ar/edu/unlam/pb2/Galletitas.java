package ar.edu.unlam.pb2;

public class Galletitas extends Comestible{

	public Galletitas(Integer clave, String nombre, String fechaCreacion, String fechaVencimiento, String marca, Double precio) {
		super(clave,nombre,fechaCreacion,fechaVencimiento,marca,precio);
	}

}
