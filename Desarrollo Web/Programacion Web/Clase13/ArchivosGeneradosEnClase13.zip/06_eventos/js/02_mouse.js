document.addEventListener('mousedown',function(e){
    switch(e.which){
        case 1:
            console.log("izquierda");
        break;
        case 2:
            console.log("ruedita");
        break;
        case 3:
            console.log("derecha");
        break;
    }
});