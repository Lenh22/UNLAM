var numero=5; //global
const IVA=21;
function sumar(){
    if(numero=5){
        let resultado=numero+8;
        console.log(resultado);
    }
}
let texto1="Programación ";
let texto2="Web 1";
//console.log(texto1+texto2);
console.log(`Concateno texto con variable ${texto1} y la otra variable ${texto2}`);
