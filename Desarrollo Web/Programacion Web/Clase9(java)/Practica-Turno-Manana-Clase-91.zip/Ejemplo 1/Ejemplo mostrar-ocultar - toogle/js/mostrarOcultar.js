$(document).ready(function() 
{ 
    $("#mostrar").toggle(

    function() 
	{
        $(".texto").hide();
        $("#mostrar").empty();
        $("#mostrar").append("Mostrar");
    },

    function() 
	{
        $(".texto").show();
        $("#mostrar").empty();
        $("#mostrar").append("Ocultar");
    }                        
    );
});

