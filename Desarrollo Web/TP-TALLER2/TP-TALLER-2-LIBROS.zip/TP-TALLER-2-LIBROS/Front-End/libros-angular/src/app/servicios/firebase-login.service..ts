
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/compat/auth';
import { Router } from '@angular/router';
import firebase from 'firebase/compat/app';
import { CookieService } from 'ngx-cookie-service';
import { environment } from 'src/environments/environment';
import { Usuario } from '../modulos/DataUsuario';
import { AngularFireDatabase } from '@angular/fire/compat/database';
import { UsuarioService } from './usuario.service';
import { resolveModuleName } from 'typescript';
import { TransitiveCompileNgModuleMetadata } from '@angular/compiler';


@Injectable({
  providedIn: 'root',
})
export class FirebaseLoginService {
  token: string;
  user: any;
  usuario: Usuario;
  usuarios: Usuario[];
  loading: boolean = false;
  pudoAgregarlo: boolean;
  apodo: string;
  mailVerif: any;
  constructor(
    private http: HttpClient,
    private router: Router,
    private afAuth: AngularFireAuth,
    private cookie: CookieService,
    public db: AngularFireDatabase,
    private usuarioService : UsuarioService
  ) {
      this.usuario ={
        userName: "",
        email: "",
        contraseña: "",
        nombre: "",
        apellido: "",
        domicilio: "",
        id: "",
        rol: "user",
        activo: false,
      }
  }

   


  //saveDataUser
  saveDataUser(
    id: string,
    userName: string,
    email: string,
    nombre: string,
    apellido: string,
    domicilio: string
  ) {
    try {
      const result = this.db.database.ref('usuario/' + id).set({
        id: id,
        userName: userName,
        email: email,
        nombre: nombre,
        apellido: apellido,
        domicilio: domicilio,
      });
      return result;
    } catch (error) {
      return error;
    }
  }

  //signup
  signupFirebase(
    userName: string,
    email: string,
    password: string,
    repetirPassword: string,
    nombre: string,
    apellido: string,
    domicilio: string
  ) {
    // console.log( userName,email,password,repetirPassword, nombre,apellido, domicilio);

  
    this.usuario.userName = userName;
    this.usuario.email = email;
    this.usuario.contraseña = password;
    this.usuario.nombre = nombre;
    this.usuario.apellido = apellido;
    this.usuario.domicilio = domicilio;

    

    this.afAuth
      .createUserWithEmailAndPassword(email, password)
      .then((user) => {
        const uid = user?.user?.uid || '';
      
        //aca empieza la parte de user a la BD

        this.usuario.id = uid;
        this.usuario.userName = userName;
        this.usuario.email = email;
        this.usuario.contraseña = password;
        this.usuario.nombre = nombre;
        this.usuario.apellido = apellido;
        this.usuario.domicilio = domicilio;  

       // console.log(this.usuario);
       

        this.saveDataBaseUser(this.usuario);
        this.verifyEmail(); 
        
        //this.saveDataUser(uid, userName, email, nombre, apellido, domicilio);
             
      })
      .catch((error) => {
        console.log(error);
      });
    
  }
    verifyEmail(){
      this.afAuth.currentUser.then(user => user?.sendEmailVerification())
                            .then(()=>{
                              alert('Se le ha enviado a su email la confirmacion de registro. Muchas gracias!');
                              this.router.navigate([''])
                            });
    }

  //login
  loginFirebase(email: string, password: string) {
    console.log('loginFirebase');
    this.traeUsuario(email, password);
    this.afAuth
      .signInWithEmailAndPassword(email, password)
      .then((user) => {
        if(user.user?.emailVerified){ //Pregunta si esta verificado el email
          this.user = user?.user?.email;
          console.log(user);
          localStorage.setItem("user", this.apodo);
          localStorage.setItem("email",user?.user?.email?email:"No hay email");
          localStorage.setItem("uid", user?.user?.uid);
         
          if (user) {
            this.getTokenFirebase();
            this.getInfoUser(user?.user?.uid || '');
            window.location.href = '';
          }
           console.log(user?.user.email);
           console.log(user?.user?.uid);

          
          
           
        }else{
          alert('Por favor, verifique su email');
        }
      })
      .catch((error) => {
        console.log(error);
      });
       
  }

    //traigo User
    traeUsuario(email: string, contraseña: string){
      console.log("Traer usuario");
      this.usuarioService.traeUser(email, contraseña).subscribe((arg) => {
        // const datas = JSON.stringify(arg); //convertir a string
        //   const datos = JSON.parse(datas); //convertir a objeto
        //   console.log("Traer usuario");
        //   console.log(datos[0]);
        //  this.apodo = <string>datos[0].userName; //asignar el nombre
        //  console.log(this.apodo);
        if (arg) {
          localStorage.setItem("traerUsuario", JSON.stringify(arg));
          console.log(arg);
          this.apodo = arg.nombre;
          console.log(this.apodo);
        }
          return this.apodo;
      });
  
    }

  getInfoUser(id: string) {
    const url = environment.firebase + '/usuario/' + id + '.json';
    this.http.get(url).subscribe(
      (resp) => {
        console.log("getInfoUser")
        console.log(resp);
      },
      (error) => console.log(error)
    );
  }

  getTokenFirebase() {
    firebase
      .auth()
      .currentUser?.getIdToken()
      .then((token) => {
        this.token = token;
        this.cookie.set('token', this.token);
        console.log('token=>', this.token);
      });
  }

  getIdToken() {
    // return this.token;
    return this.cookie.get('token');
  }

  isLogin() {
    
    return this.cookie.get('token');
    // return this.token;
  }

  //logOut
  logOut() {
    firebase
      .auth()
      .signOut()
      .then(() => {
        this.token = '';
        this.cookie.set('token', this.token);
        console.log('token vacio=>', this.token);
        //Borro el user y el uid del local Storage
        localStorage.removeItem('user');
        localStorage.removeItem('uid');
        localStorage.removeItem('email');
        
         
      });
  }
//Recuperacion de Clave
  recuperarClave(email:string){
    this.loading = true;
    this.afAuth.sendPasswordResetEmail(email).then(() => {
    alert("Se ha enviado un mensaje al email: "+ email);
    }).catch((error)=>{
      this.loading=false;
    });
  }

//guardo en BD el Usuario
  saveDataBaseUser(usuario: Usuario){
    
    this.usuarioService.agregarUsuario(usuario)
  }




}
