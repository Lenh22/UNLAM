export interface loginSendData{
    usuario:string,
    contrasenia:string
}