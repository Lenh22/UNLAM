<form action="saludo.php" method="get">
    <input type="text" id="nombre" name="nombre">
    <button type="submit">Saludar</button>
</form>