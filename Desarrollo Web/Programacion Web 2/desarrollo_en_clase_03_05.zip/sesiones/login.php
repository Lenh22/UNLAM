<?php
session_start();

$usuario = isset( $_POST["usuario"])?$_POST["usuario"] : "";
$pass = isset( $_POST["pass"])?$_POST["pass"] : "";

if ( validarUsuario($usuario, $pass) == TRUE){
    $_SESSION["usuario"] = $usuario;
    header("location:paginaPrincipal.php");
    exit();
} else {
    header("location:loginForm.php");
    exit();
}

function validarUsuario($usuario, $pass){
    return $usuario == "facu" && $pass == "1234";
}