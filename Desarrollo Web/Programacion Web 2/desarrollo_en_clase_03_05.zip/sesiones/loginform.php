<?php
session_start();

if( isset($_SESSION["usuario"]) ){
    header("location:paginaPrincipal.php");
    exit();
}
?>

<form action="login.php" method="post">
    <input type="text" id="usuario" name="usuario">
    <input type="password" id="pass" name="pass">
    <button type="submit">Login</button>
</form>