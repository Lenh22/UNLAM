<?php
session_start();

if( isset($_GET["nombre"] )){
    $_SESSION["nombre"] = $_GET["nombre"];
}

echo "hola " . $_SESSION["nombre"]  .  "!";