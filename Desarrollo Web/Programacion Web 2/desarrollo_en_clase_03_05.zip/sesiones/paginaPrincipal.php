<?php
session_start();

if( !isset($_SESSION["usuario"]) ){
    header("location:loginForm.php");
    exit();
}


echo "Página principal!!!";