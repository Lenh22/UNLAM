<?php
//Conectar con el servidor de bases de datos
//Seleccionar una base de datos
$conexion = new mysqli("localhost", "root", "", "ejemplo", 3333);

if ( $conexion->connect_error ){
    die( "Error en conexion<br>");
} else {
    echo "Conexion exitosa!<br>";
}

//Enviar la instrucción SQL a la base de datos
$sql = "select * from persona";

$result = $conexion->query($sql);

// Obtener y procesar los resultados
$resultAsArray = $result->fetch_all(MYSQLI_ASSOC);
foreach ($resultAsArray as $fila){
    echo "id: " . $fila["id"]. " - Nombre: " . $fila["nombre"]. " " . $fila["apellido"]. "<br>";
}

//Cerramos conexión a la abse de datos
$conexion->close();

/*
// Trae la consulta fila a fila
if ($result->num_rows > 0) {
    while($fila = $result->fetch_assoc()) {
        echo "id: " . $fila["id"]. " - Nombre: " . $fila["nombre"]. " " . $fila["apellido"]. "<br>";
    }
} else {
    echo "0 results";
}
*/
