<html>
<body>

<form action="procesarSaludo.php" method="GET">
    Nombre: <input type="text" name="nombre"><br>
    <input type="submit">
</form>

</body>
</html>