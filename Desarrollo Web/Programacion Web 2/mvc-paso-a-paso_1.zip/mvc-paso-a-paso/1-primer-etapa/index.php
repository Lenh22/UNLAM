<?php
session_start();
include_once("helpers/Configuration.php");

$page = $_GET["page"];

switch ($page){
    case "tours":
        $presentacionesController = Configuration::createPresentacionesController();
        $presentacionesController->mostrarPresentaciones();
        break;
    case "songs":
        $cancionesController = Configuration::createCancionesController();
        $cancionesController->mostrarCanciones();
        break;
    default:
        include_once("view/labandaView.php");
        break;
}