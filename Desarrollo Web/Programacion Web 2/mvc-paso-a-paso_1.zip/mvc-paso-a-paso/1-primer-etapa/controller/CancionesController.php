<?php


class CancionesController
{
    private $cancionesModel;

    public function __construct($cancionesModel){
        $this->cancionesModel = $cancionesModel;
    }

    public function mostrarCanciones(){
        $canciones = $this->cancionesModel->getCanciones();
        include_once("view/cancionesView.php");
    }
}