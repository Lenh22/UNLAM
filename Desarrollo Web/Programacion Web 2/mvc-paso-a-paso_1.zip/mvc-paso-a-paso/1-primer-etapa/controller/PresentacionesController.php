<?php


class PresentacionesController
{
    private $presentacionesModel;

    public function __construct($presentacionesModel){
        $this->presentacionesModel = $presentacionesModel;
    }

    public function mostrarPresentaciones(){
        $presentaciones = $this->presentacionesModel->getPresentaciones();
        include_once("view/presentacionesView.php");
    }
}