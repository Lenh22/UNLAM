<?php
require_once("helpers/MyDatabase.php");
class Configuration{

    public static function createPresentacionesController(){
        require_once("controller/PresentacionesController.php");
        return new PresentacionesController( self::createPresentacionesModel() );
    }

    public static function createCancionesController(){
        require_once("controller/CancionesController.php");
        return new CancionesController( self::createCancionesModel() );
    }

    private static function createCancionesModel(){
        require_once("model/CancionesModel.php");
        $database = self::getDatabase();
        return new CancionesModel($database);
    }

    private static function createPresentacionesModel(){
        require_once("model/PresentacionesModel.php");
        $database = self::getDatabase();
        return new PresentacionesModel($database);
    }

    private static function getDatabase(){
        $config = self::getConfig();
        return new MyDatabase($config["servername"], $config["username"], $config["password"], $config["dbname"]);
    }

    private static function getConfig(){
        return parse_ini_file("config/config.ini");
    }
}