<?php

$conn = new mysqli("localhost", "pw", "Programacion2!", "pw");


if ($conn->connect_error) {
    die("Error !!!! " . $conn->connect_error);
}



$sql = "SELECT * from usuario where usuario = ? and clave = ?;";

$stmt = $conn->prepare($sql);
$usuario = $_POST["usuario"];
$clave = $_POST["clave"];

$stmt->bind_param("ss", $usuario, $clave);


$stmt->execute();
$result = $stmt->get_result();
$fila = $result->fetch_assoc();

var_dump($fila);
/*
$stmt->execute();
$stmt->bind_result($fila);
while ($stmt->fetch()) {
    echo $fila;
}
*/

/*
$nombre = "pepe";
$clave = "pepe";

$stmt = $conn->prepare("INSERT INTO usuario VALUES (?, ?)");
$stmt->bind_param("ss", $nombre, $clave);
$stmt->execute();
$stmt->close();
$conn->close();
*/

?>
