<?php
//session_start();

$cookie_nombre = "Hola";
$cookie_valor = "Buen dia";
setcookie($cookie_nombre, $cookie_valor, time() - (86400 * 30), "/");



if(!isset($_COOKIE[$cookie_nombre])) {
  echo "Cookie no seteada, Cookie nombre: " . $cookie_nombre;
  echo " El valor es: " . $_COOKIE[$cookie_nombre];
} else {
    echo "Cookie nombre: " . $cookie_nombre;
    echo " El valor es: " . $_COOKIE[$cookie_nombre];
}
?>



